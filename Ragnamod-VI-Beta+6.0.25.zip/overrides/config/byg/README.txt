If you need help understanding what the byg-biomes or byg-sub-biomes configs allow you to do, please watch this video: https://youtu.be/iq0q09O7ZYo

If you need help with datapacking, please watch this: https://youtu.be/TF_p8OeB-hc